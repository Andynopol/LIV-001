document.getElementById('Initialize').addEventListener('click', function () {
    document.getElementById('InitializeOutput').innerHTML = API.Initialize('');
    verifyError();
    API.SetValue('cmi.exit', 'suspend');
    verifyError();
});

document.getElementById('Store').addEventListener('click', function () {
    document.getElementById('StoreOutput').innerHTML = API.SetValue('cmi.suspend_data', Math.random());
    verifyError();
});

document.getElementById('Retrieve').addEventListener('click', function () {
    document.getElementById('RetrieveOutput').innerHTML = API.GetValue('cmi.suspend_data');
    verifyError();
});

document.getElementById('Complete').addEventListener('click', function () {
    document.getElementById('CompleteOutput').innerHTML = API.SetValue('cmi.completion_status', 'completed');
    verifyError();
});

document.getElementById('Terminate').addEventListener('click', function () {
    document.getElementById('TerminateOutput').innerHTML = API.Terminate('');
    verifyError();
});

document.getElementById('RequestInfo').addEventListener('click', function () {
    document.getElementById('RequestInfoOutput').innerHTML = 'Requesting...';
    API.RequestBookInfo(function(payload) {
        if (payload) {
            document.getElementById('RequestInfoOutput').innerHTML =  JSON.stringify(payload).substr(0,32);
            console.log('RequestInfoOutput', payload);
        } else {
            document.getElementById('RequestInfoOutput').innerHTML = 'Error';
        }
    });
});

var timeout;
var errorBar = document.getElementById('errorBar');

function verifyError() {
    var errorCode = API.GetLastError();
    if (errorCode !== '0') {
        clearTimeout(timeout);
        timeout = setTimeout(hideErrorBar, 2000);
        errorBar.innerHTML = 'Error ' + errorCode + ' (' + API.GetErrorString(errorCode) + ')';
        errorBar.classList.add('up');
    }
}

function hideErrorBar() {
    errorBar.classList.remove('up');
}