import React from 'react';
import ReactDOM from 'react-dom';
import {MuiThemeProvider, CssBaseline, createMuiTheme} from '@material-ui/core';

import App from './App';

// =====================================================================================================================
//  D E C L A R A T I O N S
// =====================================================================================================================
const theme = createMuiTheme({
    typography: {
        fontFamily: 'GoogleRoboto, sans-serif',
    },
});

// =====================================================================================================================
//  S T A R T
// =====================================================================================================================
ReactDOM.render(
    <React.StrictMode>
        <MuiThemeProvider theme={theme}>
            <CssBaseline>
                <App/>
            </CssBaseline>
        </MuiThemeProvider>
    </React.StrictMode>,
    document.getElementById('root')
);
