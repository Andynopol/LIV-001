import React from 'react';
import {Button, withStyles} from '@material-ui/core';

import GoogleRoboto400 from './fonts/GoogleRoboto_400_all_v20_KFOmCnqEu92Fr1Me5g.woff';
import GoogleRoboto500 from './fonts/GoogleRoboto_500_all_v20_KFOlCnqEu92Fr1MmEU9vAA.woff';
import GoogleRoboto700 from './fonts/GoogleRoboto_700_all_v20_KFOlCnqEu92Fr1MmWUlvAA.woff';

// =====================================================================================================================
//  D E C L A R A T I O N S
// =====================================================================================================================
const style = {
    '@font-face': [
        {
            fontFamily: 'GoogleRoboto',
            fontStyle: 'normal',
            fontWeight: 400,
            src: `url(${GoogleRoboto400}) format('woff')`,
            fontDisplay: 'block',
        },
        {
            fontFamily: 'GoogleRoboto',
            fontStyle: 'normal',
            fontWeight: 500,
            src: `url(${GoogleRoboto500}) format('woff')`,
            fontDisplay: 'block',
        },
        {
            fontFamily: 'GoogleRoboto',
            fontStyle: 'normal',
            fontWeight: 700,
            src: `url(${GoogleRoboto700}) format('woff')`,
            fontDisplay: 'block',
        },
    ],
};

// =====================================================================================================================
//  C O M P O N E N T
// =====================================================================================================================
class App extends React.PureComponent {

    render() {
        return (
            <div>
                <Button color="primary">Hello World</Button>
            </div>
        );
    }

    // -----------------------------------------------------------------------------------------------------------------
    //  I N T E R N A L
    // -----------------------------------------------------------------------------------------------------------------

}

// =====================================================================================================================
//  E X P O R T
// =====================================================================================================================
export default withStyles(style)(App);