const execSync = require('child_process').execSync;

module.exports = (command, env) => {
    if (env) {
        env = {...process.env, ...env};
    }
    execSync(command, {stdio: 'inherit', env});
};