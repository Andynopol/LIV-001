const fs = require('fs');
/*
---------------------------Input:
foo
//¥a xxx b
a yyy b
bar
---------------------------Output:
foo
a xxx b
bar
*/
module.exports = (filePath) => {
    const input = fs.readFileSync(filePath, 'utf8');
    const output = input.replace(
        new RegExp('//¥(.*)\n.*', 'g'),
        '$1'
    );
    if (output !== input) {
        fs.writeFileSync(filePath, output);
    }
};