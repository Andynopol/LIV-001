const fs = require('fs');
/*
---------------------------Input:
foo
a xxx b
bar
---------------------------Action:
xxx => yyy
---------------------------Output:
foo
//¥a xxx b
a yyy b
bar
*/
module.exports = (filePath, expectedCount, ...pairs) => {
    const input = fs.readFileSync(filePath, 'utf8');
    if (input.indexOf('//¥') >= 0) {
        throw new Error(`You must restore first!\nfilePath: ${filePath}`);
    }
    let output = input;
    for (let i = 0; i < pairs.length; i += 2) {
        const original = pairs[i].toString().slice(1, -1);
        const replacement = pairs[i + 1];
        output = output.replace(
            new RegExp('^(.*)(' + original + ')(.*)$', 'mg'),
            '//¥$1$2$3\n$1' + replacement + '$3'
        );
    }
    const count = (output.match(/\/\/¥/g) || []).length;
    if (count !== expectedCount) {
        throw new Error(`Unexpected count!\nfilePath: ${filePath}\ncount: ${count}\nexpectedCount: ${expectedCount}`);
    }
    if (output !== input) {
        fs.writeFileSync(filePath, output);
    }
};