const inject = require('./utils/inject');
const restore = require('./utils/restore');
const run = require('./utils/run');

// =====================================================================================================================
//  R E S T O R A T I O N
// =====================================================================================================================
restore('node_modules/react-scripts/config/webpack.config.js');

// =====================================================================================================================
//  I N J E C T I O N
// =====================================================================================================================
inject('node_modules/react-scripts/config/webpack.config.js', 2,
    // ---------------------
    /new ManifestPlugin/,
    'false && new ManifestPlugin',
    // ---------------------
    /new WorkboxWebpackPlugin/,
    'false && new WorkboxWebpackPlugin',
);

// =====================================================================================================================
//  R U N
// =====================================================================================================================
run('react-scripts build', { // add " --stats" to obtain a comprehensive json
    GENERATE_SOURCEMAP: 'false',
});